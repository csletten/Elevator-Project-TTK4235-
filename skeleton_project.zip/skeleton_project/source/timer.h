#include <stdio.h>
#include <stdlib.h>

void timer_start_timer(int msec);

int timer_check_expired();

void timer_print_current_time();

void timer_test_timer();