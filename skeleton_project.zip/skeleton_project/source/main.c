#include <stdio.h>
#include <stdlib.h>
#include "elevator.h"

int main(){
    run_elevator();
}
